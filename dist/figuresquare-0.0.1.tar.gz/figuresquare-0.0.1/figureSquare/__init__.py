from .figuresquare import *
