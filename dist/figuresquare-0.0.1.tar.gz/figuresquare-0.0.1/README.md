## figureSquare ##

***figureSquare*** is library for calculating square of traingles (based on 3 sides of triangles) and circles (based on radius). 

